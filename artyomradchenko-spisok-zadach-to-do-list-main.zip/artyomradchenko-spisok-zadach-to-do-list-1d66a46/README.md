# spisok-zadach-to-do-list

MVP веб-приложения «Список задач» на React + TypeScript + Tailwind CSS
